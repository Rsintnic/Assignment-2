#include "stdafx.h"
#include "Engine.h"

#include <iostream>
#include "SystemManager.h"
#include "Window.h"
#include <stdio.h>

namespace core {
	//Screen dimension constants
	const int SCREEN_WIDTH = 640;
	const int SCREEN_HEIGHT = 480;

	Engine::Engine(scene::Scene* _mainScene) : mainScene(_mainScene)
	{
		isRunning = false;
		managers.push_back(new SystemManager());
	}


	Engine::~Engine()
	{
	}

	int Engine::init()
	{
		int initResult = 0;
		managers[0]->Init();

		return initResult;
	}

	int Engine::run() {
		isRunning = true;
		Input* inputSystem = dynamic_cast<SystemManager*>(managers[0])->GetSystem<Input>();
		while ( !inputSystem->QuitRequested())
		{
			// Update
			Update();
			// Render
			Draw();

		}

		return Shutdown();

	}

	bool Engine::Init() {
		mainScene->Init();

		return true;
	}

	void Engine::Update() {
		mainScene->Update();
		for (Manager* m : managers) {
			m->Update();
		}
	}

	void Engine::Draw() const{
		mainScene->Draw();
	}

	bool Engine::Shutdown() {
		if (!mainScene->Shutdown()) {
			return 1;
		}
		for (Manager* m : managers) {
			m->Shutdown();
		}

		//Quit SDL subsystems
		SDL_Quit();

		return 0;
	}

	void Engine::print()
	{
		std::cout << "this is working" << std::endl;
	}

}