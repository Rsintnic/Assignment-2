#include "stdafx.h"
#include "GameObject.h"

namespace scene {

	GameObject::GameObject()
	{
	}


	GameObject::~GameObject()
	{
	}

	bool GameObject::Init() {
		return true;
	}

	void GameObject::Update() {

	}

	void GameObject::Draw() const {

	}

	bool GameObject::Shutdown() {
		return true;
	}
}
