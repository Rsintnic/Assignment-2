#include "stdafx.h"
#include "System.h"

namespace core {
	System::System(SystemType system) : type(system) {
		
	}

	System::~System() {

	}
}