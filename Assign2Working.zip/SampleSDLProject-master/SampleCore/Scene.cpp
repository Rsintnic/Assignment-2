#include "stdafx.h"
#include "Scene.h"

namespace scene {
	Scene::Scene()
	{
	}


	Scene::~Scene()
	{
	}

	bool Scene::Init() {
		return true;
	}

	void Scene::Update() {

	}

	void Scene::Draw() const {

	}

	bool Scene::Shutdown() {
		return true;
	}
}