#include "stdafx.h"
#include "MainScene.h"
#include <SystemManager.h>
#include <Input.h>
#include <Window.h>


MainScene::MainScene()
{
}


MainScene::~MainScene()
{
}

bool MainScene::Init() {
	std::cout << "Scene init" << std::endl;
	return true;
}

void MainScene::Update() {
	using namespace core;
	SystemManager* sm = SystemManager::GetInstance();
	Input* input = dynamic_cast<core::Input*>(sm->GetSystem<core::Input>());
	Window* window = dynamic_cast<core::Window*>(sm->GetSystem<core::Window>());

	if(input->IsLeftPressed()) {
		printf("Left is pressed from scene.");
	}
	//std::cout << "Scene update" << std::endl;
}

void MainScene::Draw() const {
	//std::cout << "Scene draw" << std::endl;
}

bool MainScene::Shutdown() {
	std::cout << "Scene shutdown" << std::endl;
	return true;
}
