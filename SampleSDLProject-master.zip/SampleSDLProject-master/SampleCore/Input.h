#pragma once

#include "System.h"
namespace core {
	class Input : public System
	{
		bool quitRequested;
		bool leftIsPressed = false;
	public:
		Input();
		~Input();

		bool Init() override;
		void Update() override;
		void Draw() const override;
		bool Shutdown() override;
		inline bool IsLeftPressed() const { return leftIsPressed; }
		System* make_system(SystemType type);

		inline bool QuitRequested() const { return quitRequested; }
	};
}
