#include "stdafx.h"
#include "Manager.h"

namespace core {
	Manager::Manager()
	{
	}


	Manager::~Manager()
	{
	}
}